using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RecruitCatAdekunle.Pages
{
    public class OurTeamModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
